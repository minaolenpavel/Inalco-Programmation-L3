def isPosInt(var):
    if var>=0 and isinstance(var, int):
        return True
    else:
        return False